<?php

defined('_JEXEC') or die;

jimport( 'joomla.application.component.model');


class DredixSliderManagerModelCPanel extends JModel {

	function __construct()
	{
		parent::__construct();
	}
}
?>
