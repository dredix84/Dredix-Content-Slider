DROP TABLE `#__dredixslidermanager`;
